"""Append the no-MF4 sequences (the big recovery prize, ~2,138) to
retry_targets.csv.

Input: the notebook-10 alignment probe csv from Drive
(outputs/alignment/alignment_eda/<probe csv>). Tolerant to column naming:
any row whose error/status mentions 'no_mf4' is a target.

Usage:  python add_nomf4_targets.py <path-to-probe-csv>
"""
import sys

import pandas as pd

probe = pd.read_csv(sys.argv[1], dtype=str).fillna("")
mask = pd.Series(False, index=probe.index)
for col in probe.columns:
    mask |= probe[col].str.contains("no_mf4", case=False, na=False)
hits = probe[mask]
assert "sequence_id" in probe.columns, f"columns: {list(probe.columns)}"

targets = pd.read_csv("retry_targets.csv", dtype=str)
new = pd.DataFrame({
    "fml_id": hits["sequence_id"].str.split("_").str[0],
    "sequence_id": hits["sequence_id"],
    "reason": "no_mf4",
})
merged = (pd.concat([targets, new])
          .drop_duplicates("fml_id", keep="first")
          .reset_index(drop=True))
merged.to_csv("retry_targets.csv", index=False)
print(f"added {len(merged) - len(targets)} no_mf4 targets "
      f"-> retry_targets.csv now {len(merged)} rows")
print(merged.reason.value_counts().to_string())
