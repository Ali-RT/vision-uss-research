"""Targeted FML re-download: repair only the sequences our inventory flagged.

MODIFIED from the original full-corpus downloader. Differences:
  1. TARGETED: only sequences whose FML id appears in retry_targets.csv are
     touched; everything else is skipped instantly while paginating.
  2. The original `is_sequence_already_processed` check is BYPASSED for
     targets - that check is why a plain rerun would skip exactly the broken
     sequences (they were logged as "processed" even when downloads failed
     or the source folder was empty at the time).
  3. FILE-LEVEL REPAIR: a file is only downloaded if it is missing locally
     or zero bytes, so a sequence that only lacks its .mf4 fetches just the
     .mf4. Safe to point at the existing download tree.
  4. Separate log namespace ("<project>__retry") with its own page cursor,
     plus an end-of-run report of targets never seen in the API (tells you
     "gone from FML" apart from "download failed again").

Run on the internal-network Windows machine (requests_negotiate_sspi), NOT
Colab. Resumable: rerun any time; it continues from the last completed page.

Inputs : retry_targets.csv  (columns: fml_id, sequence_id, reason)
Outputs: repaired files under DOWNLOAD_DIR, retry_download_log.json,
         retry_report.csv (per-target outcome)
"""

import json
import os
import re
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd
import requests
import urllib3
from requests_negotiate_sspi import HttpNegotiateAuth

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


def safe_name(text: str) -> str:
    return re.sub(r'[<>:"/\\|?*]+', "_", str(text))


def is_unc_path(path: str) -> bool:
    return isinstance(path, str) and path.startswith("\\\\")


def norm_path_str(path: str) -> str:
    return os.path.normpath(str(path)).rstrip("\\/").lower()


def dedupe_keep_order(paths):
    seen, out = set(), []
    for p in paths:
        if not p:
            continue
        key = norm_path_str(p)
        if key not in seen:
            seen.add(key)
            out.append(p)
    return out


def path_is_under_root(path: str, root: str) -> bool:
    try:
        p, r = norm_path_str(path), norm_path_str(root)
        return p == r or p.startswith(r + os.sep.lower()) or p.startswith(r + "\\")
    except Exception:
        return False


class FMLClient:
    def __init__(self, base_url: str, verify_ssl: bool = False, timeout: int = 60):
        self.base_url = base_url.rstrip("/")
        self.verify_ssl = verify_ssl
        self.timeout = timeout
        self.login_session = requests.Session()
        self.login_session.auth = HttpNegotiateAuth()
        self.login_session.headers.update({"accept": "*/*"})
        self.api_session = requests.Session()
        self.api_session.headers.update({"accept": "application/json"})
        self.access_token = None

    def _resolve_url(self, path: str) -> str:
        if path.startswith(("http://", "https://")):
            return path
        if not path.startswith("/"):
            path = "/" + path
        return f"{self.base_url}{path}"

    def authenticate(self) -> str:
        resp = self.login_session.get(
            f"{self.base_url}/general/api/login",
            verify=self.verify_ssl, timeout=self.timeout)
        resp.raise_for_status()
        token = resp.json()["accessToken"].strip()
        if token.count(".") != 2:
            raise ValueError("Returned token is not a valid JWT")
        self.access_token = token
        self.api_session.headers.update({"authorization": token})
        return token

    def request(self, method, path, *, params=None, json_body=None,
                stream=False, use_nt_auth=False):
        if not self.access_token:
            self.authenticate()
        url = self._resolve_url(path)
        session = self.login_session if use_nt_auth else self.api_session
        resp = session.request(method=method.upper(), url=url, params=params,
                               json=json_body, verify=self.verify_ssl,
                               timeout=self.timeout, stream=stream,
                               allow_redirects=True)
        resp.raise_for_status()
        return resp

    def get_sequences_page(self, project_id, items_per_page=25, page_index=0,
                           properties=None, filter_query=None):
        params = {"itemsPerPage": items_per_page, "pageIndex": page_index}
        if properties:
            params["properties"] = properties
        if filter_query:
            params["filterQuery"] = filter_query
        return self.request(
            "GET", f"/api/v3/project/{project_id}/sequence", params=params).json()

    def download_http_file(self, url_or_path, output_path, use_nt_auth=False):
        resp = self.request("GET", url_or_path, stream=True, use_nt_auth=use_nt_auth)
        content_type = (resp.headers.get("content-type") or "").lower()
        if "text/html" in content_type:
            raise RuntimeError(
                f"Expected binary file but got HTML. Final URL: {resp.url} "
                f"Content-Type: {content_type} Snippet: {resp.text[:300]}")
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        with open(output_path, "wb") as f:
            for chunk in resp.iter_content(chunk_size=1024 * 1024):
                if chunk:
                    f.write(chunk)
        return output_path

    def copy_unc_file(self, unc_path, output_path):
        if not is_unc_path(unc_path):
            raise ValueError(f"Not a UNC path: {unc_path}")
        if not os.path.exists(unc_path):
            raise FileNotFoundError(f"UNC path not accessible: {unc_path}")
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        shutil.copy2(unc_path, output_path)
        return output_path

    def download_any_file(self, file_path, output_path):
        if is_unc_path(file_path):
            return self.copy_unc_file(file_path, output_path)
        elif file_path.startswith(("http://", "https://")):
            return self.download_http_file(file_path, output_path, use_nt_auth=False)
        elif file_path.startswith("/"):
            try:
                return self.download_http_file(file_path, output_path, use_nt_auth=False)
            except Exception:
                return self.download_http_file(file_path, output_path, use_nt_auth=True)
        else:
            raise ValueError(f"Unsupported file path format: {file_path}")

    def has_ffmpeg(self):
        return shutil.which("ffmpeg") is not None

    def convert_webm_to_mp4(self, input_path, delete_original=False):
        input_file = Path(input_path)
        if input_file.suffix.lower() != ".webm":
            return str(input_file)
        if not self.has_ffmpeg():
            raise RuntimeError("ffmpeg is not installed or not on PATH")
        output_file = input_file.with_suffix(".mp4")
        cmd = ["ffmpeg", "-y", "-i", str(input_file), "-c:v", "libx264",
               "-c:a", "aac", "-pix_fmt", "yuv420p", "-movflags", "+faststart",
               str(output_file)]
        result = subprocess.run(cmd, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, text=True)
        if result.returncode != 0:
            raise RuntimeError(f"ffmpeg failed for {input_file}\n{result.stderr}")
        if delete_original:
            input_file.unlink(missing_ok=True)
        return str(output_file)

    def download_preview_file(self, preview_path, output_path,
                              convert_webm=True, delete_original_webm=False):
        saved = self.download_any_file(preview_path, output_path)
        if convert_webm and Path(saved).suffix.lower() == ".webm":
            saved = self.convert_webm_to_mp4(saved, delete_original=delete_original_webm)
        return saved


def load_log(log_path):
    if os.path.exists(log_path):
        with open(log_path, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


def save_log(log_path, log):
    tmp = log_path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(log, f, indent=2, ensure_ascii=False)
    os.replace(tmp, log_path)


def infer_sequence_folder(seq):
    for mf in seq.get("measurementFiles") or []:
        p = mf.get("path")
        if isinstance(p, str) and p:
            return os.path.dirname(p)
    for p in seq.get("previewFilePaths") or []:
        if isinstance(p, str) and p:
            return os.path.dirname(p)
    return None


def list_all_files_in_folder(folder_path, recursive=True):
    if not folder_path or not os.path.exists(folder_path):
        return []
    out = []
    try:
        if recursive:
            for root, _, files in os.walk(folder_path):
                for name in files:
                    out.append(os.path.join(root, name))
        else:
            for name in os.listdir(folder_path):
                full = os.path.join(folder_path, name)
                if os.path.isfile(full):
                    out.append(full)
    except Exception:
        return []
    return sorted(out)


def get_measurement_file_paths(seq):
    return [mf.get("path") for mf in (seq.get("measurementFiles") or [])
            if isinstance(mf.get("path"), str) and mf.get("path")]


def local_target_path(source_path, seq_dir, source_folder):
    base_name = os.path.basename(source_path.rstrip("\\/")) or "unknown.bin"
    if source_folder and path_is_under_root(source_path, source_folder):
        rel = os.path.relpath(source_path, source_folder)
        return os.path.join(seq_dir, rel)
    return os.path.join(seq_dir, base_name)


def file_needs_download(target_path: str) -> bool:
    """Repair-mode gate: only fetch what is missing or empty. A .webm whose
    converted .mp4 already exists also counts as present."""
    p = Path(target_path)
    if p.exists() and p.stat().st_size > 0:
        return False
    if p.suffix.lower() == ".webm":
        mp4 = p.with_suffix(".mp4")
        if mp4.exists() and mp4.stat().st_size > 0:
            return False
    return True


# -- Config -------------------------------------------------------------------

BASE_URL = "https://rb-fml.de.bosch.com"
PROJECT_ID = "uss_pf"
ITEMS_PER_PAGE = 25
MAX_PAGES = None                      # retry run walks all pages
DOWNLOAD_DIR = "downloads_all/uss_pf" # SAME tree as the original run
TARGETS_CSV = "retry_targets.csv"
LOG_FILE = "retry_download_log.json"
REPORT_CSV = "retry_report.csv"
DRY_RUN = True                        # first pass: see what would be fetched
CONVERT_XLSX_TO_CSV = True
DELETE_ORIGINAL_WEBM = False
DELETE_ORIGINAL_XLSX = False

# -- Run ----------------------------------------------------------------------

targets_df = pd.read_csv(TARGETS_CSV, dtype=str)
targets = {str(r.fml_id): {"sequence_id": r.sequence_id, "reason": r.reason,
                           "seen_in_api": False, "files_fetched": 0,
                           "files_failed": 0, "files_already_ok": 0}
           for r in targets_df.itertuples()}
print(f"targets: {len(targets)} "
      f"({targets_df.reason.value_counts().to_dict()})")

client = FMLClient(BASE_URL, verify_ssl=False)
client.authenticate()
os.makedirs(DOWNLOAD_DIR, exist_ok=True)

log = load_log(LOG_FILE)
retry_key = f"{PROJECT_ID}__retry"
proj = log.setdefault(retry_key, {"next_page_index": 0, "sequences": {}})
page_index = proj["next_page_index"] if not DRY_RUN else 0
print(f"DRY_RUN={DRY_RUN}  starting at page {page_index}")

while True:
    if MAX_PAGES is not None and page_index >= MAX_PAGES:
        break
    page = client.get_sequences_page(
        project_id=PROJECT_ID, items_per_page=ITEMS_PER_PAGE,
        page_index=page_index,
        properties=["id", "name", "previewFilePaths", "measurementFiles"])
    if not page:
        print("pagination complete.")
        break

    hits = [s for s in page if str(s.get("id")) in targets]
    if hits:
        print(f"page {page_index}: {len(hits)} target(s)")
    for seq in hits:
        seq_id = str(seq.get("id"))
        t = targets[seq_id]
        t["seen_in_api"] = True
        seq_name = seq.get("name", f"seq_{seq_id}")
        seq_dir = os.path.join(DOWNLOAD_DIR, f"{seq_id}_{safe_name(seq_name)}")

        preview_paths = [p for p in (seq.get("previewFilePaths") or [])
                         if isinstance(p, str) and p]
        measurement_paths = get_measurement_file_paths(seq)
        source_folder = infer_sequence_folder(seq)
        folder_paths = list_all_files_in_folder(source_folder) if source_folder else []
        all_sources = dedupe_keep_order(measurement_paths + preview_paths + folder_paths)
        preview_set = {norm_path_str(p) for p in preview_paths}

        print(f"\n[{t['reason']}] {seq_id} | {seq_name}")
        print(f"  source folder: {source_folder}  files listed: {len(all_sources)}")
        if not all_sources:
            print("  -> STILL no source files visible on FML")
            continue

        for source_path in all_sources:
            target_path = local_target_path(source_path, seq_dir, source_folder)
            if not file_needs_download(target_path):
                t["files_already_ok"] += 1
                continue
            if DRY_RUN:
                print(f"  [would fetch] {source_path} -> {target_path}")
                t["files_fetched"] += 1
                continue
            try:
                if norm_path_str(source_path) in preview_set:
                    saved = client.download_preview_file(
                        source_path, target_path, convert_webm=True,
                        delete_original_webm=DELETE_ORIGINAL_WEBM)
                else:
                    saved = client.download_any_file(source_path, target_path)
                t["files_fetched"] += 1
                print(f"  [ok] {saved}")
                if CONVERT_XLSX_TO_CSV and Path(saved).suffix.lower() == ".xlsx":
                    import openpyxl  # noqa: F401 - fail early if missing
                    excel = pd.ExcelFile(saved, engine="openpyxl")
                    single = len(excel.sheet_names) == 1
                    for sheet in excel.sheet_names:
                        df = pd.read_excel(saved, sheet_name=sheet, engine="openpyxl")
                        stem = Path(saved).stem
                        name = (f"{stem}.csv" if single else
                                f"{stem}__{safe_name(sheet).strip('_') or 'Sheet'}.csv")
                        df.to_csv(Path(saved).with_name(name), index=False,
                                  encoding="utf-8-sig")
                    if DELETE_ORIGINAL_XLSX:
                        Path(saved).unlink(missing_ok=True)
            except Exception as e:
                t["files_failed"] += 1
                print(f"  [ERR] {source_path} -> {e}")

        if not DRY_RUN:
            proj["sequences"][seq_id] = {
                "processed_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                "fetched": t["files_fetched"], "failed": t["files_failed"]}
            save_log(LOG_FILE, log)

    if not DRY_RUN:
        proj["next_page_index"] = page_index + 1
        save_log(LOG_FILE, log)
    if len(page) < ITEMS_PER_PAGE:
        print("last page reached.")
        break
    page_index += 1

# -- Report -------------------------------------------------------------------
rows = [{"fml_id": k, **v} for k, v in targets.items()]
report = pd.DataFrame(rows)
report.to_csv(REPORT_CSV, index=False)
print("\n--- Retry summary -------------------")
print(f"targets seen in API     : {report.seen_in_api.sum()}/{len(report)}")
print(f"targets NEVER in API    : {(~report.seen_in_api).sum()} "
      f"(these sequences are gone from FML - unrecoverable)")
print(f"files fetched{' (would)' if DRY_RUN else ''} : {report.files_fetched.sum()}")
print(f"files already ok        : {report.files_already_ok.sum()}")
print(f"files failed            : {report.files_failed.sum()}")
print(f"report                  : {REPORT_CSV}")
